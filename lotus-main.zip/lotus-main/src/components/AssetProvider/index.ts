import AssetProvider from './AssetProvider.container'
export { AssetProvider }
