import GenderBadge from './GenderBadge.container'

export default GenderBadge
