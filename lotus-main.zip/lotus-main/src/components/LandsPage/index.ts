import LandsPage from './LandsPage.container'
export { LandsPage }
