import UserMenu from './UserMenu.container'

export default UserMenu
