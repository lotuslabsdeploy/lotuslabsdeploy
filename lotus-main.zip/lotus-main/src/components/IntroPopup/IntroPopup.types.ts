export type Props = {}

export type State = {
  open: boolean
}
