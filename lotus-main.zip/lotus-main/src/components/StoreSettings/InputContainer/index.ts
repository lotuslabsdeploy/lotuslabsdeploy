import InputContainer from './InputContainer'

export default InputContainer
