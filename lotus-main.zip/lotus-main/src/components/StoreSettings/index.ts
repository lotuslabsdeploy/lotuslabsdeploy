import StoreSettings from './StoreSettings.container'

export default StoreSettings
