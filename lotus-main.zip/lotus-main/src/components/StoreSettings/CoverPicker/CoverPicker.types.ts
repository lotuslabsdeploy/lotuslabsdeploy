export type Props = {
  src?: string
  onChange: (src?: string, name?: string, size?: number) => void
}
