import CoverPicker from './CoverPicker'

export default CoverPicker
