import { VendorName } from '../../modules/vendor/types'

export type Props = {
  onMenuItemClick: (vendor: VendorName) => void
}
