import OnSaleListElement from './OnSaleListElement'

export default OnSaleListElement
