import OnSaleList from './OnSaleList.container'

export default OnSaleList
