import AssetCell from './AssetCell'

export default AssetCell
