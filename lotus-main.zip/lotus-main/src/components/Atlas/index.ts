import Atlas from './Atlas.container'
export { Atlas }
