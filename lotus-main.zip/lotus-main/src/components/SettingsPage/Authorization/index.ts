import Authorization from './Authorization.container'
export { Authorization }
