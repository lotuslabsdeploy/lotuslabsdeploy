import SettingsPage from './SettingsPage.container'
export { SettingsPage }
