import HomePage from './HomePage.container'
export { HomePage }
