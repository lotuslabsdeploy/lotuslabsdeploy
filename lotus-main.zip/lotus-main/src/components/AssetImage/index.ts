import AssetImage from './AssetImage.container'
export { AssetImage }
