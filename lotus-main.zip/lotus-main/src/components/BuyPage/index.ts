import BuyPage from './BuyPage'
export { BuyPage }
