import { Network } from '@dcl/schemas'

export type Props = {
  network: Network
  price: string
}
