import { AssetType } from '../../modules/asset/types'

export type Props = {
  type: AssetType
}
