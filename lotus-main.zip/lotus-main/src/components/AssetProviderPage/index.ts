import AssetProviderPage from './AssetProviderPage.container'
export { AssetProviderPage }
