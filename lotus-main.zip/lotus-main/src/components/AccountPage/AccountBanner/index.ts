import AccountBanner from './AccountBanner.container'

export default AccountBanner
