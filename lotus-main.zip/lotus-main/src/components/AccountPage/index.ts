import AccountPage from './AccountPage.container'
export { AccountPage }
