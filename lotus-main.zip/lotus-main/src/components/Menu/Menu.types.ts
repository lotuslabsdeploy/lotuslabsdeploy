import React from 'react'

export type Props = {
  className?: string
  children: React.ReactNode
}
