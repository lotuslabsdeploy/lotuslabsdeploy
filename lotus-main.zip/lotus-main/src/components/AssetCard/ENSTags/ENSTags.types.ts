import { NFT } from '../../../modules/nft/types'

export type Props = {
  nft: NFT
}
