import ParcelTags from './ParcelTags'
export { ParcelTags }
