import ProximityTags from './ProximityTags.container'
export { ProximityTags }
