import { Item } from '@dcl/schemas'
import { NFT } from '../../../modules/nft/types'

export type Props = {
  asset: NFT | Item
}
