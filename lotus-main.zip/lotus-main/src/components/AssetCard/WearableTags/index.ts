import WearableTags from './WearableTags'
export { WearableTags }
