import EmoteTags from './EmoteTags'
export { EmoteTags }
