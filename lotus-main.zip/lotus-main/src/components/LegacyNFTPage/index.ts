import LegacyNFTPage from './LegacyNFTPage'
export { LegacyNFTPage }
