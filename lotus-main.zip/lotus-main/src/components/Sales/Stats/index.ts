import Stats from './Stats.container'

export default Stats
