import Activity from './Activity.container'

export default Activity
