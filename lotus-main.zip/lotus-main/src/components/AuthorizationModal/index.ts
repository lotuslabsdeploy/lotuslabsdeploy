import AuthorizationModal from './AuthorizationModal.container'
export { AuthorizationModal }
