import { ManaProps } from 'decentraland-ui'

export type Props = ManaProps & {
  withTooltip?: boolean
}
