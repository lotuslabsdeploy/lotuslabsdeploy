import OtherAccountSidebar from './OtherAccountSidebar.container'

export default OtherAccountSidebar
