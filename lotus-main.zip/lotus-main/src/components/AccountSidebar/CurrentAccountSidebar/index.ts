import CurrentAccountSidebar from './CurrentAccountSidebar'

export default CurrentAccountSidebar
