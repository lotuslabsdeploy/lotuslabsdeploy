import ActivityPage from './ActivityPage.container'
export { ActivityPage }
