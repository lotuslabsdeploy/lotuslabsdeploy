import TransactionDetail from './TransactionDetail'
export { TransactionDetail }
