import { Transaction } from 'decentraland-dapps/dist/modules/transaction/types'

export type Props = {
  tx: Transaction
}
