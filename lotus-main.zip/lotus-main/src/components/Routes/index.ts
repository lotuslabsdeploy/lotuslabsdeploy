import Routes from './Routes'

export { Routes }
