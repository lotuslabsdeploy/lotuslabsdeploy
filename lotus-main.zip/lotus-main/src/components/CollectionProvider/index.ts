import CollectionProvider from './CollectionProvider.container'

export default CollectionProvider
