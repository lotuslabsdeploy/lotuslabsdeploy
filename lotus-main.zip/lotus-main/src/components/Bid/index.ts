import Bid from './Bid.container'
export { Bid }
