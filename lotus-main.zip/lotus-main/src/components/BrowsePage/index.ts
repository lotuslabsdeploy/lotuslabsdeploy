import BrowsePage from './BrowsePage.container'
export { BrowsePage }
