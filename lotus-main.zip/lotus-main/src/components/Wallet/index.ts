import Wallet from './Wallet.container'
export { Wallet }
