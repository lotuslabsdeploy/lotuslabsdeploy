import EmoteDetail from './EmoteDetail'
export { EmoteDetail }
