import AssetPage from './AssetPage.container'

export { AssetPage }
