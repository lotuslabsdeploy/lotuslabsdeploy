export type Props = {
  text?: string | null
}
