import CategoryBadge from './CategoryBadge.container'

export default CategoryBadge
