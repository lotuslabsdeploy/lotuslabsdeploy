export type Props = {}

export type State = {
  hasError: boolean
}
