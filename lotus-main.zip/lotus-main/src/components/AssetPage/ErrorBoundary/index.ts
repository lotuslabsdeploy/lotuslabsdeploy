import ErrorBoundary from './ErrorBoundary'
export { ErrorBoundary }
