import BidList from './BidList.container'
export { BidList }
