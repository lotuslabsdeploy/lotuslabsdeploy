import SmartBadge from './SmartBadge.container'

export default SmartBadge
