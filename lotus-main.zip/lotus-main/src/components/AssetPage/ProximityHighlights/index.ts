import ProximityHighlights from './ProximityHighlights.container'
export { ProximityHighlights }
