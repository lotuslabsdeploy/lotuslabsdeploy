export type Props = {
  x: number
  y: number
  className?: string
}
