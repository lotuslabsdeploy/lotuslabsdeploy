import ENSDetail from './ENSDetail'
export { ENSDetail }
