import Price from './Price.container'

export default Price
