import ParcelDetail from './ParcelDetail'

export { ParcelDetail }
