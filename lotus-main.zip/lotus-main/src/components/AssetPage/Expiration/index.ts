import Expiration from './Expiration.container'

export default Expiration
