import ParcelCoordinates from './ParcelCoordinates.container'
export { ParcelCoordinates }
