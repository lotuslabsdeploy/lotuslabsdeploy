import EstateDetail from './EstateDetail'

export { EstateDetail }
