import Collection from './Collection'

export default Collection
