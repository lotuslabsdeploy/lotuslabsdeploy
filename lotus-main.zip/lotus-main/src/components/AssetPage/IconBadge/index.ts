import IconBadge from './IconBadge'

export default IconBadge
