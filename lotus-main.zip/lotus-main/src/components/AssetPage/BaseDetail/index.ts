import BaseDetail from './BaseDetail'

export default BaseDetail
