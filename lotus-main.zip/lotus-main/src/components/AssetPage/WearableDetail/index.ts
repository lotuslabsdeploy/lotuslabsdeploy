import WearableDetail from './WearableDetail'
export { WearableDetail }
