import { Asset } from '../../../modules/asset/types'

export type Props = {
  asset: Asset | null
}

export type MapStateProps = {}
export type MapDispatchProps = {}
