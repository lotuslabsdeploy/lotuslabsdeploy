import ItemDetail from './ItemDetail.container'

export { ItemDetail }
