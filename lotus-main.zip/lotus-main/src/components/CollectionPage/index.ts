import CollectionPage from './CollectionPage.container'

export default CollectionPage
