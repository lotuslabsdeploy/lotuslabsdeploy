import BidPage from './BidPage.container'
export { BidPage }
