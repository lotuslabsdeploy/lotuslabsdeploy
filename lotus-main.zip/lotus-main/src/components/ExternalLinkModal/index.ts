import ExternalLinkModal from './ExternalLinkModal'

export default ExternalLinkModal
