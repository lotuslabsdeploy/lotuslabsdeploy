export type Props = {
  link: string
  onClose: () => void
}
