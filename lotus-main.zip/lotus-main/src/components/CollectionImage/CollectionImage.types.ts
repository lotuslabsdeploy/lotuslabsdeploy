export type Props = {
  contractAddress: string
}
