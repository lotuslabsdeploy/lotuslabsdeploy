import CollectionImage from './CollectionImage'

export default CollectionImage
