import RarityBadge from './RarityBadge.container'

export default RarityBadge
