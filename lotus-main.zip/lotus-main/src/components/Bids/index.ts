import Bids from './Bids.container'
export { Bids }
