import TransferPage from './TransferPage.container'
export { TransferPage }
