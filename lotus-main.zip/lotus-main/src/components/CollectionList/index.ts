import CollectionList from './CollectionList.container'

export default CollectionList
